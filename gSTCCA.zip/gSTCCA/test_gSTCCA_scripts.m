%% Add data path
cur_path = pwd;
cd('/Code/CCA');
addpath(genpath('Dataset'));
addpath(genpath(pwd))
addpath('/Code/CCA/Test_scripts/tensor_toolbox-v3.2.1')
cd(cur_path)

%% Load face data
% data_normalization = 1; Use_MPCA = 0;
% data_name_all = {'YaleB_32x32', 'Yale_32x32', 'Yale_64x64', 'ORL_32x32', 'ORL_64x64','AR'};
% mode_all = {'wavelet','LBP','Downsample'};
% 
% ratio = 0.1;
% mode = mode_all{2};
% dataset_name = data_name_all{6};
% 
% max_iter = 10;
% dim = 10; dim_x = dim; dim_y = 10;
% epsilon = 0.15;
% tolerance = 0.01;
% normalize = 1;
% t_selected = 100;
% initialize = 'rand_new';
% 
% for m = 2
%     mode = mode_all{m};
%     [X, Y, label] = load_face_recog_dataset(dataset_name, mode, data_normalization);
%     if(data_normalization == 0)
%         X = X/max(X(:));  Y = Y/max(Y(:)); 
%     end
%      N = length(label); idx_all = 1:N;
%      Ndim_X = ndims(X);
%     
%     disp(['#############################################################'])
%     disp(['testing: STAR',' dataset: ',dataset_name,' ','mode: ',mode, ' normalization: ',num2str(data_normalization), ' Use_MPCA = ',num2str(Use_MPCA)])
%     disp(['#############################################################'])
%     
%     for ratio_test_per_class = 0.2
%         iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%         for rng_factor = 000:111:999
%             % data preprocessingc
%             idx_test_select = select_test_ratio(label, ratio_test_per_class, rng_factor);
%             idx_train_select = setdiff(idx_all, idx_test_select);
%             label_test = label(idx_test_select);
%             label_train = label(idx_train_select);
%             
%             if(Ndim_X == 3)
%                 
%                 X_test = X(:,:,idx_test_select); X_train = X(:,:,idx_train_select);
%                 Y_test = Y(:,:,idx_test_select); Y_train = Y(:,:,idx_train_select);
%                 
%                 if(Use_MPCA == 1)
%                     Ux_MPCA = MPCA(X_train,0.98); Uy_MPCA = MPCA(Y_train,0.98);
%                     X_train = proj_2DCCA(X_train,Ux_MPCA{1},Ux_MPCA{2}); Y_train = proj_2DCCA(Y_train,Uy_MPCA{1},Uy_MPCA{2});
%                     X_test = proj_2DCCA(X_test,Ux_MPCA{1},Ux_MPCA{2}); Y_test = proj_2DCCA(Y_test,Uy_MPCA{1},Uy_MPCA{2});
%                 end
% 
%                 tic
%                 [Ux,Uy, ~, ~, record_iter] = STAR(X_train, Y_train, max_iter, dim_x, dim_y, epsilon, tolerance, normalize, initialize, t_selected);
%                 feature_extract_time(iter) = toc;
%                 
%                 X_train_proj = proj_2DCCA(X_train, Ux{1}, Ux{2}); Y_train_proj = proj_2DCCA(Y_train, Uy{1}, Uy{2});
%                 X_test_proj = proj_2DCCA(X_test,  Ux{1}, Ux{2}); Y_test_proj = proj_2DCCA(Y_test, Uy{1}, Uy{2});
%                 
%                 sparsity(iter) = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Uy{1}) + nnz(Uy{2}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Uy{1}) + numel(Uy{2}));
%                 sparsity(iter) = 1 - sparsity(iter);
%                 
%             elseif(Ndim_X == 4)
%                 
%                 X_test = X(:,:,:,idx_test_select); X_train = X(:,:,:,idx_train_select);
%                 Y_test = Y(:,:,:,idx_test_select); Y_train = Y(:,:,:,idx_train_select);
%                 
%                 if(Use_MPCA == 1)
%                     Ux_MPCA = MPCA(X_train,0.98); Uy_MPCA = MPCA(Y_train,0.98);
%                     X_train = proj_3DCCA(X_train,Ux_MPCA); Y_train = proj_3DCCA(Y_train,Uy_MPCA);
%                     X_test = proj_3DCCA(X_test,Ux_MPCA); Y_test = proj_3DCCA(Y_test,Uy_MPCA);
%                 end
%                 
%                 tic
%                 [Ux,Uy, ~, ~, record_iter] = STAR(X_train, Y_train, max_iter, dim_x, dim_y, epsilon, tolerance, normalize,initialize,t_selected);
%                 feature_extract_time(iter) = toc;
%                 
%                 X_train_proj = proj_3DCCA(X_train,Ux); Y_train_proj = proj_3DCCA(Y_train,Uy);
%                 X_test_proj = proj_3DCCA(X_test,Ux); Y_test_proj = proj_3DCCA(Y_test,Uy);
%                 
%                 sparsity(iter) = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Ux{3}) + nnz(Uy{1}) + nnz(Uy{2}) + nnz(Ux{3}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Ux{3}) + numel(Uy{1}) + numel(Uy{2}) + numel(Uy{3}));
%                 sparsity(iter) = 1 - sparsity(iter);
%                 
%             end
%             
%             vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%             vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
%             
%             vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%             vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
%             
%             Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%             Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
% 
%             % Classify
%             knn = 1;
%             estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%             acc_KNN = cal_acc(estimate, label_test);
% 
%             svmModel = fitcecoc(Final_train_feature,label_train);
%             [estimate,SCORE] = predict(svmModel, Final_test_feature);
%             acc_SVM = cal_acc(estimate, label_test);
% 
%             disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%             acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%             iter = iter + 1;
% 
%         end
%         
%         train_time = 0;
%         
%         avg_train_time = mean(train_time); std_train_time = std(train_time);
%         avg_feature_extract_time = mean(feature_extract_time); std_feature_extract_time = std(feature_extract_time);
%         
%         disp(['#############################################################'])
%         disp(['testing: STAR',' dataset: ',dataset_name,' ','mode: ',mode, ' normalization: ',num2str(data_normalization), ' Use_MPCA = ',num2str(Use_MPCA)])
%         disp(['#############################################################'])
%         
%         disp(['testing: STAR',' dataset: ',dataset_name])
%         disp(['ratio_test_per_class = ',num2str(ratio_test_per_class)])
%         disp(['avg_train_time = ',num2str(avg_train_time), ' std_train_time = ',num2str(std_train_time)])
%         disp(['avg_feature_extract_time = ',num2str(avg_feature_extract_time), ' std_feature_extract_time = ',num2str(std_feature_extract_time)])
%         disp(['avg_sparsity = ', num2str(mean(sparsity)), ' std_sparsity = ', num2str(std(sparsity))])
%         disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%         disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%         disp('********************************************************************************')
%                 
%        
%     end
% end

%% Load CASME data

% data_normalization = 1; Use_MPCA = 1; rank = 30;
% 
% dataset_name = 'CASME';warning('off')
% 
% disp(['#############################################################'])
% disp(['testing: STAR',' dataset: ',' CASME ',' ', ' normalization: ',num2str(data_normalization), ' Use_MPCA = ',num2str(Use_MPCA), ' rank = ',num2str(rank)])
% disp(['#############################################################'])
% 
% load CASME1_LBP_coding
% load CASME1
% 
% idx_1 = find(label_all == 1)'; idx_4 = find(label_all == 4)';
% idx_3 = find(label_all == 3)';
% idx_6 = find(label_all == 6)'; idx_7 = find(label_all == 7)';
% idx_selected = [idx_1; idx_3; idx_4; idx_6; idx_7];
% 
% X = LBP_coding_video(:,:,:,idx_selected); Y = video_tensor(:,:,:,idx_selected);
% label = label_all(idx_selected);N = length(label); idx_all = 1:N;
% 
% if(data_normalization == 1)
%     X = my_normalize_tensor(X); Y = my_normalize_tensor(Y);
% else
%     X = X/max(X(:)); Y = Y/max(Y(:));
% end
% 
% if(Use_MPCA == 1)
%     Ux_MPCA = MPCA_by_rank(X,rank); Uy_MPCA = MPCA_by_rank(Y,rank);
%     X = proj_3DCCA(X,Ux_MPCA); Y = proj_3DCCA(Y,Uy_MPCA);
% end
% 
% max_iter = 10;
% dim = 30; dim_x = dim; dim_y = 30;
% epsilon = 0.15;
% tolerance = 0.01;
% normalize = 0;
% t_selected = 100;
% initialize = 'rand';
% 
% ratio = 0.1;
% for number_train_per_class = 3
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 000:111:999
%         % data preprocessing
%         idx_train_select = select_test(label, number_train_per_class, rng_factor);
%         idx_test_select = setdiff(idx_all, idx_train_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
%         
%         X_test = X(:,:,:,idx_test_select); X_train = X(:,:,:,idx_train_select);
%         Y_test = Y(:,:,:,idx_test_select); Y_train = Y(:,:,:,idx_train_select);
%         
%         tic
%         [Ux,Uy, ~, ~, record_iter] = STAR(X_train, Y_train, max_iter, dim_x, dim_y, epsilon, tolerance, normalize, initialize, t_selected);
%         feature_extract_time(iter) = toc;
%         
%         sparsity(iter) = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Ux{3}) + nnz(Uy{1}) + nnz(Uy{2}) + nnz(Uy{3}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Ux{3}) + numel(Uy{1}) + numel(Uy{2}) + numel(Uy{3}));
%         sparsity(iter) = 1 - sparsity(iter);
%         
%         X_test_proj = proj_3DCCA(X_test, Ux); Y_test_proj = proj_3DCCA(Y_test, Uy);
%         X_train_proj = proj_3DCCA(X_train, Ux); Y_train_proj = proj_3DCCA(Y_train, Uy);
%         
%         vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%         vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
%         
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
%         
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
%         
%         %   Classification
%         knn = 1;
%         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%         acc_KNN = cal_acc(estimate, label_test);
%         
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
%         
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;   
%         iter = iter + 1;
%         
%     end
%     
%     train_time = 0;
%     
%     avg_train_time = mean(train_time); std_train_time = std(train_time);
%     avg_feature_extract_time = mean(feature_extract_time); std_feature_extract_time = std(feature_extract_time);
%     
%     disp(['testing: STAR',' dataset: ',dataset_name])
%     disp(['number_train_per_class = ',num2str(number_train_per_class)])
%     disp(['avg_train_time = ',num2str(avg_train_time), ' std_train_time = ',num2str(std_train_time)])
%     disp(['avg_sparsity = ', num2str(mean(sparsity)), ' std_sparsity = ', num2str(std(sparsity))])
%     disp(['avg_feature_extract_time = ',num2str(avg_feature_extract_time), ' std_feature_extract_time = ',num2str(std_feature_extract_time)])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')
%     
% end

%% Load Other data

data_normalization = 1; Use_MPCA = 0;
% dataset_name = 'Gait17_32x22x10_processed'; [X,Y,label] = load_dataset(dataset_name, data_normalization);
% dataset_name = 'JAFFE'; mode = 'paired'; [X,Y,label] = load_JAFFE_dataset(data_normalization, mode);
% dataset_name = 'HIV'; mode = 'normal'; [X,Y,label] = load_dataset(dataset_name, data_normalization);
dataset_name = 'Mnist_012_processed_new'; mode = 'normal'; [X,Y,label] = load_dataset(dataset_name, data_normalization);

ratio = 0.1;
max_iter = 10;
dim = 30; dim_x = dim; dim_y = 30;
epsilon = 0.15;
tolerance = 0.01;
normalize = 0;
t_selected = 100;
initialize = 'rand_new';

disp(['max_iter: ',num2str(max_iter),' dim_x: ',num2str(dim_x), ' dim_y: ',num2str(dim_y), ' epsilon: ',num2str(epsilon), ' normalize: ', num2str(normalize),' t_selected: ',num2str(t_selected), ' initialize: ', initialize])

N = length(label); idx_all = 1:N;
Ndim_X = ndims(X); Ndim_Y = ndims(Y);

disp(['#############################################################'])
disp(['testing: STAR',' dataset: ',dataset_name,' normalization: ',num2str(data_normalization), ' Use_MPCA = ',num2str(Use_MPCA)])
disp(['#############################################################'])

for ratio_test_per_class = 0.2
    iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
    for rng_factor = 000:111:999
        % data preprocessingc
        idx_test_select = select_test_ratio(label, ratio_test_per_class, rng_factor);
        idx_train_select = setdiff(idx_all, idx_test_select);
        label_test = label(idx_test_select);
        label_train = label(idx_train_select);
        
        if(Ndim_X == 3)
            X_test = X(:,:,idx_test_select); X_train = X(:,:,idx_train_select);
            Y_test = Y(:,:,idx_test_select); Y_train = Y(:,:,idx_train_select);
            
            if(Use_MPCA == 1)
                Ux_MPCA = MPCA(X_train,0.98); Uy_MPCA = MPCA(Y_train,0.98);
                X_train = proj_2DCCA(X_train,Ux_MPCA{1},Ux_MPCA{2}); Y_train = proj_2DCCA(Y_train,Uy_MPCA{1},Uy_MPCA{2});
                X_test = proj_2DCCA(X_test,Ux_MPCA{1},Ux_MPCA{2}); Y_test = proj_2DCCA(Y_test,Uy_MPCA{1},Uy_MPCA{2});
            end
            
            tic
            [Ux,Uy, ~, ~, record_iter] = STAR(X_train, Y_train, max_iter, dim_x, dim_y, epsilon, tolerance, normalize, initialize, t_selected);
            feature_extract_time(iter) = toc;
            
            X_train_proj = proj_2DCCA(X_train, Ux{1}, Ux{2}); Y_train_proj = proj_2DCCA(Y_train, Uy{1}, Uy{2});
            X_test_proj = proj_2DCCA(X_test,  Ux{1}, Ux{2}); Y_test_proj = proj_2DCCA(Y_test, Uy{1}, Uy{2});
            
            sparsity(iter) = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Uy{1}) + nnz(Uy{2}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Uy{1}) + numel(Uy{2}));
            sparsity(iter) = 1 - sparsity(iter);
            
        elseif(Ndim_X == 4)
            
            X_test = X(:,:,:,idx_test_select); X_train = X(:,:,:,idx_train_select);
            Y_test = Y(:,:,:,idx_test_select); Y_train = Y(:,:,:,idx_train_select);
            
            if(Use_MPCA == 1)
                Ux_MPCA = MPCA(X_train,0.98); Uy_MPCA = MPCA(Y_train,0.98);
                X_train = proj_3DCCA(X_train,Ux_MPCA); Y_train = proj_3DCCA(Y_train,Uy_MPCA);
                X_test = proj_3DCCA(X_test,Ux_MPCA); Y_test = proj_3DCCA(Y_test,Uy_MPCA);
            end
            
            tic
            [Ux,Uy, ~, ~, record_iter] = STAR(X_train, Y_train, max_iter, dim_x, dim_y, epsilon, tolerance, normalize, initialize, t_selected);
            feature_extract_time(iter) = toc;
            
            X_train_proj = proj_3DCCA(X_train,Ux); Y_train_proj = proj_3DCCA(Y_train,Uy);
            X_test_proj = proj_3DCCA(X_test,Ux); Y_test_proj = proj_3DCCA(Y_test,Uy);
            
            sparsity(iter) = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Ux{3}) + nnz(Uy{1}) + nnz(Uy{2}) + nnz(Uy{3}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Ux{3}) + numel(Uy{1}) + numel(Uy{2}) + numel(Uy{3}));
            sparsity(iter) = 1 - sparsity(iter);
            
        end
        
        vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
        vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
        
        vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
        vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
        
        Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
        Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
        
        Ux_all{iter} = Ux; Uy_all{iter} = Uy;
        
        % Classify
        knn = 1;
        estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
        acc_KNN = cal_acc(estimate, label_test);
        
        svmModel = fitcecoc(Final_train_feature,label_train);
        [estimate,SCORE] = predict(svmModel, Final_test_feature);
        acc_SVM = cal_acc(estimate, label_test);
        
        disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
        acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
        iter = iter + 1;
        
    end
    
    train_time = 0;
    
    avg_train_time = mean(train_time); std_train_time = std(train_time);
    avg_feature_extract_time = mean(feature_extract_time); std_feature_extract_time = std(feature_extract_time);
    
    disp(['testing: STAR',' dataset: ',dataset_name])
    disp(['ratio_test_per_class = ',num2str(ratio_test_per_class)])
    disp(['avg_train_time = ',num2str(avg_train_time), ' std_train_time = ',num2str(std_train_time)])
    disp(['avg_feature_extract_time = ',num2str(avg_feature_extract_time), ' std_feature_extract_time = ',num2str(std_feature_extract_time)])
    disp(['avg_sparsity = ', num2str(mean(sparsity)), ' std_sparsity = ', num2str(std(sparsity))])
    disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
    disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
    disp('********************************************************************************')
    
    
end

%% Test unpaired data

% data_normalization = 1; Use_MPCA = 0;
% % dataset_name = 'JAFFE'; mode = 'unpaired'; [X,Y,label] = load_JAFFE_dataset(data_normalization, mode);
% dataset_name = 'PPMI_new'; mode = 'normal'; [X,Y,label] = load_PPMI_dataset(dataset_name, data_normalization, mode);
% 
% 
% ratio = 0.1;
% max_iter = 10;
% dim = 90; dim_x = dim; dim_y = 90;
% epsilon = 0.15;
% tolerance = 0.01;
% normalize = 0;
% t_selected = 100;
% initialize = 'rand';
% 
% N = length(label); idx_all = 1:N;
% Ndim_X = ndims(X); Ndim_Y = ndims(Y);
% 
% disp(['#############################################################'])
% disp(['testing: STAR',' dataset: ',dataset_name, ' mode: ', mode,' normalization: ',num2str(data_normalization), ' Use_MPCA = ',num2str(Use_MPCA), ' dim_x = ',num2str(dim_x), ' dim_y = ', num2str(dim_y)])
% disp(['#############################################################'])
% 
% for ratio_test_per_class = 0.2
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 000:111:999
%         % data preprocessingc
%         idx_test_select = select_test_ratio(label, ratio_test_per_class, rng_factor);
%         idx_train_select = setdiff(idx_all, idx_test_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
%         
%         X_test = X(:,:,idx_test_select); X_train = X(:,:,idx_train_select);
%         Y_test = Y(:,:,:,idx_test_select); Y_train = Y(:,:,:,idx_train_select);
%         
%         tic
%         [Ux,Uy, ~, ~, record_iter] = STAR(X_train, Y_train, max_iter, dim_x, dim_y, epsilon, tolerance, normalize, initialize, t_selected);
%         feature_extract_time(iter) = toc;
%         
%         X_train_proj = proj_2DCCA(X_train,Ux{1}, Ux{2});Y_train_proj = proj_3DCCA(Y_train,Uy);
%         X_test_proj = proj_2DCCA(X_test,Ux{1}, Ux{2});Y_test_proj = proj_3DCCA(Y_test,Uy);
%         
%         sparsity(iter) = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Uy{1}) + nnz(Uy{2}) + nnz(Uy{3}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Uy{1}) + numel(Uy{2}) + numel(Uy{3}));
%         sparsity(iter) = 1 - sparsity(iter);
%         
%         vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%         vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
%         
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
%         
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
%         
%         % Classify
%         knn = 1;
%         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%         acc_KNN = cal_acc(estimate, label_test);
%         
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
%         
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%         iter = iter + 1;
%         
%     end
%     
%     train_time = 0;
%     
%     avg_train_time = mean(train_time); std_train_time = std(train_time);
%     avg_feature_extract_time = mean(feature_extract_time); std_feature_extract_time = std(feature_extract_time);
%     
%     disp(['testing: STAR',' dataset: ',dataset_name])
%     disp(['ratio_test_per_class = ',num2str(ratio_test_per_class)])
%     disp(['avg_train_time = ',num2str(avg_train_time), ' std_train_time = ',num2str(std_train_time)])
%     disp(['avg_feature_extract_time = ',num2str(avg_feature_extract_time), ' std_feature_extract_time = ',num2str(std_feature_extract_time)])
%     disp(['avg_sparsity = ', num2str(mean(sparsity)), ' std_sparsity = ', num2str(std(sparsity))])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')   
%     
% end

%% Load medical data

% data_normalization = 1; Use_MPCA = 0;
% dataset_name = 'PPMI_new'; mode = 'normal'; [X,Y,label] = load_PPMI_dataset(dataset_name, data_normalization, mode);
% 
% 
% ratio = 0.1;
% max_iter = 10;
% dim = 100; dim_x = dim; dim_y = 100;
% epsilon = 0.15;
% tolerance = 0.01;
% normalize = 0;
% t_selected = 100;
% initialize = 'rand';
% 
% N = length(label); idx_all = 1:N;
% Ndim_X = ndims(X); Ndim_Y = ndims(Y);
% 
% disp(['#############################################################'])
% disp(['testing: STAR',' dataset: ',dataset_name, ' mode: ', mode,' normalization: ',num2str(data_normalization), ' Use_MPCA = ',num2str(Use_MPCA), ' dim_x = ',num2str(dim_x), ' dim_y = ', num2str(dim_y)])
% disp(['#############################################################'])
% 
% for ratio_test_per_class = 0.2
%     
%     iter = 1;
%     acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     sensi_all_KNN = zeros(10,1); sensi_all_SVM = zeros(10,1);
%     speci_all_KNN = zeros(10,1); speci_all_SVM = zeros(10,1);
%     bac_all_KNN = zeros(10,1); bac_all_SVM = zeros(10,1);
%     precision_all_KNN = zeros(10,1); precision_all_SVM = zeros(10,1);
%     fscore_all_KNN = zeros(10,1); fscore_all_SVM = zeros(10,1);
%     
%     for rng_factor = 000:111:999
%         % data preprocessingc
%         idx_test_select = select_test_ratio(label, ratio_test_per_class, rng_factor);
%         idx_train_select = setdiff(idx_all, idx_test_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
%         
%         X_test = X(:,:,idx_test_select); X_train = X(:,:,idx_train_select);
%         Y_test = Y(:,:,:,idx_test_select); Y_train = Y(:,:,:,idx_train_select);
%         
%         tic
%         [Ux,Uy, ~, ~, record_iter] = STAR(X_train, Y_train, max_iter, dim_x, dim_y, epsilon, tolerance, normalize, initialize, t_selected);
%         feature_extract_time(iter) = toc;
%         
%         X_train_proj = proj_2DCCA(X_train,Ux{1}, Ux{2});Y_train_proj = proj_3DCCA(Y_train,Uy);
%         X_test_proj = proj_2DCCA(X_test,Ux{1}, Ux{2});Y_test_proj = proj_3DCCA(Y_test,Uy);
%         
%         sparsity(iter) = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Uy{1}) + nnz(Uy{2}) + nnz(Uy{3}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Uy{1}) + numel(Uy{2}) + numel(Uy{3}));
%         sparsity(iter) = 1 - sparsity(iter);
%         
%         vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%         vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
%         
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
%         
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
%         
%         % Classify
%         knn = 1;
%         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%         acc_KNN = cal_acc(estimate, label_test);
%         [accuracy_KNN,sensitivity_KNN,specificity_KNN,precision_KNN,f_score_KNN] = cal_metrics(estimate, label_test);
%         
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
%         
%         [accuracy_SVM,sensitivity_SVM,specificity_SVM,precision_SVM,f_score_SVM] = cal_metrics(estimate, label_test);
%         
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         
%         acc_all_KNN(iter) = accuracy_KNN; acc_all_SVM(iter) = accuracy_SVM;
%         sensi_all_KNN(iter) = sensitivity_KNN; sensi_all_SVM(iter) = sensitivity_SVM;
%         speci_all_KNN(iter) = specificity_KNN; speci_all_SVM(iter) = specificity_SVM;
%         bac_all_KNN(iter) = (specificity_KNN + sensitivity_KNN)/2; bac_all_SVM(iter) = (specificity_SVM + sensitivity_SVM)/2;
%         precision_all_KNN(iter) = precision_KNN; precision_all_SVM(iter) = precision_SVM;
%         fscore_all_KNN(iter) = f_score_KNN; fscore_all_SVM(iter) = f_score_SVM;
%                
%         iter = iter + 1;
%         
%     end
%     
%     train_time = 0;
%     
%     avg_train_time = mean(train_time); std_train_time = std(train_time);
%     avg_feature_extract_time = mean(feature_extract_time); std_feature_extract_time = std(feature_extract_time);
%     
%     disp(['testing: STAR',' dataset: ',dataset_name])
%     disp(['ratio_test_per_class = ',num2str(ratio_test_per_class)])
%     disp(['avg_train_time = ',num2str(avg_train_time), ' std_train_time = ',num2str(std_train_time)])
%     disp(['avg_feature_extract_time = ',num2str(avg_feature_extract_time), ' std_feature_extract_time = ',num2str(std_feature_extract_time)])
%     disp(['avg_sparsity = ', num2str(mean(sparsity)), ' std_sparsity = ', num2str(std(sparsity))])
%     disp(['testing: MPCA',' dataset: ',dataset_name,' ','mode: ',mode])
%     disp(['ratio_test_per_class = ',num2str(ratio_test_per_class)])
%     disp(['avg_train_time = ',num2str(avg_train_time), ' std_train_time = ',num2str(std_train_time)])
%     disp(['avg_feature_extract_time = ',num2str(avg_feature_extract_time), ' std_feature_extract_time = ',num2str(std_feature_extract_time)])
%     
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_acc_KNN = ',num2str(std(acc_all_KNN)), ' std_acc_SVM = ', num2str(std(acc_all_SVM))])
%     
%     disp([' sensi_KNN = ',num2str(mean(sensi_all_KNN)), ' sensi_SVM = ', num2str(mean(sensi_all_SVM))])
%     disp([' std_sensi_KNN = ',num2str(std(sensi_all_KNN)), ' std_sensi_SVM = ', num2str(std(sensi_all_SVM))])
%     
%     disp([' speci_KNN = ',num2str(mean(speci_all_KNN)), ' speci_SVM = ', num2str(mean(speci_all_SVM))])
%     disp([' std_speci_KNN = ',num2str(std(speci_all_KNN)), ' std_speci_SVM = ', num2str(std(speci_all_SVM))])
%     
%     disp([' bac_KNN = ',num2str(mean(bac_all_KNN)), ' bac_SVM = ', num2str(mean(bac_all_SVM))])
%     disp([' std_bac_KNN = ',num2str(std(bac_all_KNN)), ' std_bac_SVM = ', num2str(std(bac_all_SVM))])
%     
%     disp([' precision_KNN = ',num2str(mean(precision_all_KNN)), ' precision_SVM = ', num2str(mean(precision_all_SVM))])
%     disp([' std_precision_KNN = ',num2str(std(precision_all_KNN)), ' std_precision_SVM = ', num2str(std(precision_all_SVM))])
%     
%     disp([' fscore_KNN = ',num2str(mean(fscore_all_KNN)), ' fscore_SVM = ', num2str(mean(fscore_all_SVM))])
%     disp([' std_fscore_KNN = ',num2str(std(fscore_all_KNN)), ' std_fscore_SVM = ', num2str(std(fscore_all_SVM))])
%     disp('********************************************************************************') 
%     
% end