
addpath('tensorlab/');
method_name = 'STAR';

%%

V = zeros(100, 1);
V([13 24 57 73 92]) = 1;

% 2D Y true signal: 64-by-64 cross
%shapename = 'rectangle';
% shapename = 'cross';
%shapename = 'disk';
shapename = 'butterfly';
% shapename = 'flower';

shape = imread([shapename '.gif']);
shape = array_resize(shape,[32,32]); % 32-by-32
W = zeros(2*size(shape));
W((size(W,1)/4):(size(W,1)/4)+size(shape,1)-1, ...
    (size(W,2)/4):(size(W,2)/4)+size(shape,2)-1) = shape;
[p1,p2] = size(W);

figure;
set(gca, 'FontSize', 15);
subplot(1, 2, 1)
hold on;
plot(double(V), '+')
title('True V');
axis square;
subplot(1, 2, 2)
imagesc(W);
colormap(gray);
title('True W');
axis square;

% simulate joint normal random deviates
n = 1000;
rho = 0.95;
s = RandStream('mt19937ar','Seed',1);
RandStream.setGlobalStream(s);
[X, Y] = simcca(V, W(:), rho, n, 'noisex', 1, 'noisey', 1e-3);
display(corr(X * V, Y * W(:))); % sample correlation

% Test STAR

max_iter = 1;
dim = 1; dim_x = dim; dim_y = 1;
epsilon = 0.15;
tolerance = 0.01;
normalize = 0;
t_selected = 100;
initialize = 'rand';

X_my = zeros(100,10,1000);

X = X'; X_my(:,1,:) = X; X = X_my;
Y = tensor(Y', [p1 p2 n]); Y = double(Y);

[Ux,Uy, U_new, V_new, record_iter] = STAR(X, Y, max_iter, dim_x, dim_y, epsilon, tolerance, normalize, initialize, t_selected);

%% Initialize
% max_iter = 10;
% dim = 1; dim_x = dim; dim_y = 10;
% epsilon = 0.15;
% tolerance = 0.01;
% normalize = 0;
% t_selected = 100;
% initialize = 'rand';
% 
% rng('default');
% % X = rand(10,16,30); Xc = X - mean(X,ndims(X));
% X = rand(10,20,30); Xc = X - mean(X,ndims(X));
% Y = rand(20,18,30); Yc = Y - mean(Y,ndims(Y));

% [init_U] = initialize_U(Xc,R);
% [init_V] = initialize_U(Yc,R);
% 
% X_proj = cal_proj_init(Xc,init_U,R);
% Y_proj = cal_proj_init(Yc,init_V,R);
% 
% vec_X = double(tenmat(Xc, ndims(Xc)));
% vec_Y = double(tenmat(Yc, ndims(Yc)));

% [Ux,Uy, ~, ~, record_iter] = STAR(X, Y, max_iter, dim_x, dim_y, epsilon, tolerance, normalize, initialize, t_selected);
%% Run methods to match different input format

% % load('SimData.mat');
% % X = Xten(:,:,trainInd{1,1}); vec_Y = Y(trainInd{1,1}); vec_X = Xt(trainInd{1,1},:);
% 
% for i = 1:10
%     
%     % update U
%     [~,U_t,U_cell, sigma_u,res_UX] = STAR_simple(Xc, vec_X, Y_proj, R, epsilon);
%     U_new = cal_U_sum(U_t);
%     X_proj = cal_proj(Xc, U_new);
%     
%     % update V
%     [~,V_t,V_cell, sigma_v,res_VY] = STAR_simple(Yc, vec_Y, X_proj, R, epsilon);
%     V_new = cal_U_sum(V_t);
%     Y_proj = cal_proj(Yc, V_new);
%         
%     if(i == 1)
%         U_old = U_new;
%         V_old = V_new;
%     end
%     
%     if(i > 1)
%         error_U = norm(U_new - U_old,'fro');
%         error_V = norm(V_new - V_old,'fro');
%         if(error_U < tolerance && error_V < tolerance)
%             break;
%         else
%             U_old = U_new; V_old = V_new;
%         end          
%     end
%     
% end

%% Other functions

function U = initialize_U(X,R)
N = ndims(X)-1;
size_X = size(X);
U = cell(N,1);

for i = 1:N
    rng('default');Ui = randn(size_X(i), R);
    U{i} = Ui;
    %   U{i} = Ui/norm(Ui,1);
end

end

function X_proj = cal_proj_init(X,U,R)
N = ndims(X);
mode = 1:N-1;
U_r = cell(N-1,1);

sum_proj = 0;
for r = 1:R
    
    for j = 1:N-1
        U_r{j} = U{j}(:,r);
    end
    
    proj_i = double(ttm(tensor(X),U_r,mode,'t'));
    sum_proj = sum_proj + proj_i;
end

X_proj = squeeze(sum_proj);

end

function U_sum = cal_U_sum(U)
R = length(U);
U_sum = 0;

for r = 1:R
    Ur = U{r};
    if(~isempty(Ur))
        U_sum = U_sum + Ur;
    end 
end

end

function X_proj = cal_proj(X, U)
N = size(X,ndims(X));
X_proj = zeros(N,1);

for i = 1:N
    Xi = X(:,:,i);
    Xi_U = Xi.*U;
    X_proj_i = sum(Xi_U(:));
    X_proj(i,1) = X_proj_i;
end

end
