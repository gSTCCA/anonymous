clc;

addpath('tensorlab/');
addpath('\CCA\Dataset/')
addpath '\CCA\Related_lib\Multiclass_SVM'
method_name = 'gSTCCA';

%% Test MNIST 012

% Initialization
% max_iter = 10;
% dim = 10;
% epsilon = 0.15;
% tolerance = 0.01;
% 
% dataset_name = 'MNIST';
% load Mnist_012_processed_new
% X = upper_all; Y = lower_all; N = length(label); idx_all = 1:N;
% 
% X = X/max(X(:)); Y = Y/max(Y(:));
% 
% tic
% [Ux,Uy] = STAR(X, Y, max_iter, dim, dim, epsilon, tolerance);
% toc
% 
% X_proj = proj_2DCCA(X, Ux{1}, Ux{2}); Y_proj = proj_2DCCA(Y, Uy{1}, Uy{2});
% 
% for ratio_test_per_class = 0.2
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 0:111:999
%         % data preprocessing
%         idx_test_select = select_test_ratio(label, ratio_test_per_class, rng_factor);
%         idx_train_select = setdiff(idx_all, idx_test_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
% 
%         X_test_proj = X_proj(:,:,idx_test_select); X_train_proj = X_proj(:,:,idx_train_select);
%         Y_test_proj = Y_proj(:,:,idx_test_select); Y_train_proj = Y_proj(:,:,idx_train_select);
%         
%         % Perform 2DCCA (normal)
%         vec_X_train_proj = tenmat(X_train_proj,3); vec_Y_train_proj = tenmat(Y_train_proj,3);
%         vec_X_test_proj = tenmat(X_test_proj,3); vec_Y_test_proj = tenmat(Y_test_proj,3);
%         
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
%         
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
% 
%         % Classify
%         knn = 1;
%         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%         acc_KNN = cal_acc(estimate, label_test);
%         
%         tic
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
%         toc
%         %             acc_SVM = 0;
% 
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%         iter = iter + 1;
% 
%     end
%     disp(['testing: STAR',' dataset: ',dataset_name,' ', ' dim = ',num2str(dim)])
%     disp(['ratio_test_per_class = ',num2str(ratio_test_per_class)])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')
% end
% 

% max_iter = 10;
% dim = 20; dim_x = dim; dim_y = dim;
% epsilon = 0.15;
% tolerance = 0.01;
% normalize = 0;
% t_selected = 100;
% initialize = 'rand';
% 
% dataset_name = 'MNIST';
% load Mnist_012_processed_new
% X = upper_all; Y = lower_all; N = length(label); idx_all = 1:N;
% 
% data_normalization = 0;
% if(data_normalization == 1)
%     X = my_normalize_tensor(X); Y = my_normalize_tensor(Y);
% else
%     X = X/max(X(:)); Y = Y/max(Y(:)); 
% end
% 
% disp(['#############################################################'])
% disp(['testing: STAR',' dataset: ',dataset_name,' ','normalization: ',num2str(data_normalization)])
% disp(['#############################################################'])
% 
% % 
% % % svm = get_model("OVA", 3);  % K = number of classes
% % % svm.hyperparams.C = 5;
% % % svm.kernel = "rbf";
% % % svm.hyperparams.gamma = 0.1;
% % % label = label + 1;
% 
% ratio = 0.2;
% for ratio_test_per_class = 0.2
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 000:111:999
%         % data preprocessing
%         idx_test_select = select_test_ratio(label, ratio_test_per_class, rng_factor);
%         idx_train_select = setdiff(idx_all, idx_test_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
%         
%         X_train = X(:,:,idx_train_select); Y_train = Y(:,:,idx_train_select);
%         X_test = X(:,:,idx_test_select); Y_test = Y(:,:,idx_test_select);
%         
%         tic
%         [t_best] = choose_para_STAR_Kfold(X_train,Y_train,label_train,ratio);
%         train_time(iter) = toc;
%         t_selected = t_best;
%         t_best_all(iter) = t_best;
%         
%         tic
%         [Ux,Uy, ~, ~, record_iter] = STAR(X_train, Y_train, max_iter, dim_x, dim_y, epsilon, tolerance, normalize,initialize,t_selected);
%         feature_extraction_time(iter) = toc;
%         
%         record_all{iter} = record_iter;
%         Ux_all{iter} = Ux;
%         Uy_all{iter} = Uy;
%         
%         sparsity(iter) = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Uy{1}) + nnz(Uy{2}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Uy{1}) + numel(Uy{2}));
%         sparsity(iter) = 1 - sparsity(iter);
%         
%         X_test_proj = proj_2DCCA(X_test,Ux{1},Ux{2}); X_train_proj = proj_2DCCA(X_train,Ux{1},Ux{2});
%         Y_test_proj = proj_2DCCA(Y_test,Uy{1},Uy{2}); Y_train_proj = proj_2DCCA(Y_train,Uy{1},Uy{2});
%         
%         % Perform 2DCCA (normal)
%         vec_X_train_proj = tenmat(X_train_proj,3); vec_Y_train_proj = tenmat(Y_train_proj,3);
%         vec_X_test_proj = tenmat(X_test_proj,3); vec_Y_test_proj = tenmat(Y_test_proj,3);
%         
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
%         
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
% 
%         % Classify
%         knn = 1;
%         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%         acc_KNN = cal_acc(estimate, label_test);
%         
%         tic
%         
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
% %         svm = train_model(svm, Final_train_feature, label_train);
% %         estimate = svm.trained.predict(Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
%         toc
% 
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%         iter = iter + 1;
% 
%     end
%     disp(['#############################################################'])
%     disp(['testing: STAR',' dataset: ',dataset_name,' ','normalization: ',num2str(data_normalization)])
%     disp(['#############################################################'])
%     
%     avg_train_time = mean(train_time); std_train_time = std(train_time);
% 
%     disp(['testing: STAR',' dataset: ',dataset_name,' ', ' dim = ',num2str(dim)])
%     disp(['ratio_test_per_class = ',num2str(ratio_test_per_class),' avg_sparsity = ', num2str(mean(sparsity))])
%     disp(['avg_sparsity = ', num2str(mean(sparsity)), ' std_sparsity = ', num2str(std(sparsity))])
%     disp(['avg_train_time = ',num2str(avg_train_time), ' std_train_time = ',num2str(std_train_time)])
%     disp(['avg_feature_extraction_time = ', num2str(mean(feature_extraction_time)), ' std_feature_extraction_time = ', num2str(std(feature_extraction_time))])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')
%     
%     disp('acc_all_KNN')
%     acc_all_KNN
%     disp('acc_all_SVM')
%     acc_all_SVM
%     disp('t_best')
%     t_best_all
%     disp('feature_extraction_time')
%     feature_extraction_time
%     disp('sparsity_all')
%     sparsity
%     
% end

%% Test Full MNIST with noise

% % Initialization
% max_iter = 10;
% dim = 20;
% epsilon = 0.15;
% tolerance = 0.01;
% 
% load mnist_origin_noisy.mat
% 
% X_train = train_images(:,:,:); Y_train = noisy_train(:,:,:);
% X_test = test_images; Y_test = noisy_test;
% 
% Mx = mean(X_train,ndims(X_train)); My = mean(Y_train,ndims(Y_train));
% 
% label_train = train_labels + 1; label_test = test_labels + 1;
% label_train = label_train(:);
% 
% X = cat(3,X_train, X_test); Y = cat(3,Y_train, Y_test);
% max_X = max(X(:)); max_Y = max(Y(:));
% 
% svm = get_model("OVA", 10);
% svm.hyperparams.C = 5;
% svm.kernel = "rbf";
% svm.hyperparams.gamma = 0.1;
% 
% X_train = X_train/max_X; Y_train = Y_train/max_Y;
% X_test = X_test/max_X; Y_test = Y_test/max_Y;
% 
% tic
% [Ux,Uy] = STAR(X_train, Y_train, max_iter, dim, dim, epsilon, tolerance);
% toc
% 
% X_train_proj = proj_2DCCA(X_train, Ux{1}, Ux{2}); Y_train_proj = proj_2DCCA(Y_train, Uy{1}, Uy{2});
% X_test_proj = proj_2DCCA(X_test, Ux{1}, Ux{2}); Y_test_proj = proj_2DCCA(Y_test, Uy{1}, Uy{2});
% 
% vec_X_train_proj = tenmat(X_train_proj,3); vec_Y_train_proj = tenmat(Y_train_proj,3);
% vec_X_test_proj = tenmat(X_test_proj,3); vec_Y_test_proj = tenmat(Y_test_proj,3);
% 
% vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
% vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
% 
% Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
% Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
% 
% Mdl = fitcknn(Final_train_feature,label_train,'NumNeighbors',1);
% [estimate] = predict(Mdl, Final_test_feature);
% error = estimate - label_test;
% a = find(error == 0);
% acc = numel(a)/numel(label_test)
% 
% tic
% % svm = get_model("OVA", 10);
% svm = train_model(svm, Final_train_feature,label_train,'verbose', 0);
% toc
% 
% [estimate,SCORE] =  svm.trained.predict(Final_test_feature);
% 
% acc_SVM = cal_acc(estimate, label_test)
% 
% sparsity = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Uy{1}) + nnz(Uy{2}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Uy{1}) + numel(Uy{2}))

%% Test face recog

% max_iter = 10;
% dim = 30; dim_x = dim; dim_y = 15;
% epsilon = 0.15;
% tolerance = 0.01;
% normalize = 0;
% t_selected = 100;
% initialize = 'rand';
% 
% data_name_all = {'YaleB_32x32', 'Yale_32x32', 'Yale_64x64', 'ORL_32x32', 'ORL_64x64'};
% mode_all = {'wavelet','LBP','Downsample'};
% 
% for m = 3
%     mode = mode_all{m};
%     for d = 2
%         dataset_name = data_name_all{d};
%         [X, Y, label, idx_all] = load_dataset(dataset_name, mode);
% %         X = normalize_X(X); Y = normalize_X(Y);
% %         X = X/max(X(:)); Y = Y/max(Y(:));
%         X = my_normalize_tensor(X); Y = my_normalize_tensor(Y);
%         
%         for ratio_test_per_class = 0.2
%             iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%             for rng_factor = 000:111:999
% %                 data preprocessing
%                 idx_test_select = select_test_ratio(label, ratio_test_per_class, rng_factor);
%                 idx_train_select = setdiff(idx_all, idx_test_select);
%                 label_test = label(idx_test_select);
%                 label_train = label(idx_train_select);
%                 
%                 X_train = X(:,:,idx_train_select); Y_train = Y(:,:,idx_train_select);
%                 X_test = X(:,:,idx_test_select); Y_test = Y(:,:,idx_test_select);
%                 
%                 tic
%                 [Ux,Uy, ~, ~, record_iter] = STAR(X_train, Y_train, max_iter, dim_x, dim_y, epsilon, tolerance, normalize,initialize,t_selected);
%                 feature_extraction_time(iter) = toc
%                 
%                 record_all{iter} = record_iter;
%                 Ux_all{iter} = Ux;
%                 Uy_all{iter} = Uy;
%                 
%                 sparsity(iter) = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Uy{1}) + nnz(Uy{2}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Uy{1}) + numel(Uy{2}));
%                 sparsity(iter) = 1 - sparsity(iter)
%                 
%                 X_test_proj = proj_2DCCA(X_test,Ux{1},Ux{2}); X_train_proj = proj_2DCCA(X_train,Ux{1},Ux{2});
%                 Y_test_proj = proj_2DCCA(Y_test,Uy{1},Uy{2}); Y_train_proj = proj_2DCCA(Y_train,Uy{1},Uy{2});
% 
%                 vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%                 vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
% 
%                 vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%                 vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
% 
%                 Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%                 Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
% 
% %                 Classify
%                 knn = 1;
%                 estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%                 acc_KNN = cal_acc(estimate, label_test);
%                 
%                 tic
% 
%                 svmModel = fitcecoc(Final_train_feature,label_train);
%                 [estimate,SCORE] = predict(svmModel, Final_test_feature);
%                 acc_SVM = cal_acc(estimate, label_test);
%                 toc
% %                 acc_SVM = 0;
% 
%                 disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%                 acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%                 iter = iter + 1;
% 
%             end
%             disp(['testing: STAR',' dataset: ',dataset_name,' ', ' dim = ',num2str(dim)])
%             disp(['ratio_test_per_class = ',num2str(ratio_test_per_class),' avg_sparsity = ', num2str(mean(sparsity))])
%             disp(['avg_sparsity = ', num2str(mean(sparsity)), ' std_sparsity = ', num2str(std(sparsity))])
%             disp(['avg_feature_extraction_time = ', num2str(mean(feature_extraction_time)), ' std_feature_extraction_time = ', num2str(std(feature_extraction_time))])
%             disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%             disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%             disp('********************************************************************************')
%             
%             disp('acc_all_KNN')
%             acc_all_KNN
%             disp('acc_all_SVM')
%             acc_all_SVM
%             disp('feature_extraction_time')
%             feature_extraction_time
%             disp('sparsity_all')
%             sparsity
%         end
%     end
% 
% end

% max_iter = 10;
% dim = 40; dim_x = dim; dim_y = 40;
% epsilon = 0.15;
% tolerance = 0.01;
% normalize = 0;
% t_selected = 10;
% initialize = 'rand';
% 
% data_name_all = {'YaleB_32x32', 'Yale_32x32', 'Yale_64x64', 'ORL_32x32', 'ORL_64x64'};
% mode_all = {'wavelet','LBP','Downsample'};
% ratio = 0.1;
% for m = 2
%     mode = mode_all{m};
%     for d = 3
%         dataset_name = data_name_all{d};
%         [X, Y, label, idx_all] = load_dataset(dataset_name, mode);
%         
%         data_normalization = 1;
%         if(data_normalization == 1)
%             X = my_normalize_tensor(X); Y = my_normalize_tensor(Y);
%         else
%             X = X/max(X(:)); Y = Y/max(Y(:));
%         end
%         
%         for ratio_test_per_class = 0.2
%             iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%             for rng_factor = 000:111:999
% %                 data-preprocessing
%                 idx_test_select = select_test_ratio(label, ratio_test_per_class, rng_factor);
%                 idx_train_select = setdiff(idx_all, idx_test_select);
%                 label_test = label(idx_test_select);
%                 label_train = label(idx_train_select);
%                 
%                 X_train = X(:,:,idx_train_select); Y_train = Y(:,:,idx_train_select);
%                 X_test = X(:,:,idx_test_select); Y_test = Y(:,:,idx_test_select);
%                 
%                 tic
% %                 [t_best] = choose_para_STAR_Kfold(X_train,Y_train,label_train,ratio);
%                 t_best = 60;
%                 train_time(iter) = toc;
%                 t_selected = t_best;
%                 t_best_all(iter) = t_best;
%                 
%                 tic
%                 [Ux,Uy, ~, ~, record_iter] = STAR(X_train, Y_train, max_iter, dim_x, dim_y, epsilon, tolerance, normalize,initialize,t_selected);
%                 feature_extraction_time(iter) = toc;
%                 
%                 record_all{iter} = record_iter;
%                 Ux_all{iter} = Ux;
%                 Uy_all{iter} = Uy;
%                 
%                 sparsity(iter) = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Uy{1}) + nnz(Uy{2}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Uy{1}) + numel(Uy{2}));
%                 sparsity(iter) = 1 - sparsity(iter);
%                 
%                 X_test_proj = proj_2DCCA(X_test,Ux{1},Ux{2}); X_train_proj = proj_2DCCA(X_train,Ux{1},Ux{2});
%                 Y_test_proj = proj_2DCCA(Y_test,Uy{1},Uy{2}); Y_train_proj = proj_2DCCA(Y_train,Uy{1},Uy{2});
% 
%                 vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%                 vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
% 
%                 vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%                 vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
% 
%                 Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%                 Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
% 
% %                 Classify
%                 knn = 1;
%                 estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%                 acc_KNN = cal_acc(estimate, label_test);
%                 
%                 tic
% 
%                 svmModel = fitcecoc(Final_train_feature,label_train);
%                 [estimate,SCORE] = predict(svmModel, Final_test_feature);
%                 acc_SVM = cal_acc(estimate, label_test);
%                 toc
% %                 acc_SVM = 0;
% 
%                 disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%                 acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%                 iter = iter + 1;
% 
%             end
%             
%             disp(['#############################################################'])
%             disp(['testing: STAR',' dataset: ',dataset_name,' ','normalization: ',num2str(data_normalization)])
%             disp(['#############################################################'])
%             
%             avg_train_time = mean(train_time); std_train_time = std(train_time);
%             
%             disp(['testing: STAR',' dataset: ',dataset_name,' ', ' dim = ',num2str(dim)])
%             disp(['ratio_test_per_class = ',num2str(ratio_test_per_class),' avg_sparsity = ', num2str(mean(sparsity))])
%             disp(['avg_sparsity = ', num2str(mean(sparsity)), ' std_sparsity = ', num2str(std(sparsity))])
%             disp(['avg_train_time = ',num2str(avg_train_time), ' std_train_time = ',num2str(std_train_time)])
%             disp(['avg_feature_extraction_time = ', num2str(mean(feature_extraction_time)), ' std_feature_extraction_time = ', num2str(std(feature_extraction_time))])
%             disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%             disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%             disp('********************************************************************************')
%             
%             disp('acc_all_KNN')
%             acc_all_KNN
%             disp('acc_all_SVM')
%             acc_all_SVM
%             disp('t_best')
%             t_best_all
%             disp('feature_extraction_time')
%             feature_extraction_time
%             disp('sparsity_all')
%             sparsity
%             
%         end
%     end
% 
% end

%% Test Gait

% Initialization

% max_iter = 5;
% dim_x = 20; dim_y = 20;
% epsilon = 0.15;
% tolerance = 0.01;
% 
% dataset = 'Gait17_32x22x10_processed';
% load(dataset)
% X = double(U); Y = double(V);
% X = X/max(X(:));  Y = Y/max(Y(:));
% N = length(label); idx_all = 1:N;
% 
% tic
% [Ux,Uy] = STAR(X, Y, max_iter, dim_x, dim_y, epsilon, tolerance);
% toc
% 
% for num_test_per_class = 2
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 0:111:999
%         % data preprocessingc
%         idx_test_select = select_test(label, num_test_per_class, rng_factor);
%         idx_train_select = setdiff(idx_all, idx_test_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
%         X_test = X(:,:,:,idx_test_select); X_train = X(:,:,:,idx_train_select);
%         Y_test = Y(:,:,:,idx_test_select); Y_train = Y(:,:,:,idx_train_select);
% 
%         X_train_proj = proj_3DCCA(X_train,Ux);Y_train_proj = proj_3DCCA(Y_train,Uy);
%         X_test_proj = proj_3DCCA(X_test,Ux);Y_test_proj = proj_3DCCA(Y_test,Uy);
% 
%         vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%         vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
% 
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
% 
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
% 
%         % Classify
% %         knn = 1;
% %         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
% %         acc_KNN = cal_acc(estimate, label_test);
%         acc_KNN = 0;
% 
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
% %         acc_SVM = 0;
% 
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%         iter = iter + 1;
% 
%     end
%     disp(['num_test_per_class = ',num2str(num_test_per_class)])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')
% end

%% Test JAFFE

% max_iter = 50;
% dim_x = 20; dim_y = 20;
% epsilon = 0.15;
% tolerance = 0.01;
% 
% load jaffe_gabor_feature_pair
% X = Gabor_Feature_Tensor1; Y = Gabor_Feature_Tensor2;
% label = label_all;N = length(label); idx_all = 1:N;
% Ux_MPCA = MPCA(X,0.98); Uy_MPCA = MPCA(Y,0.98);
% X = proj_3DCCA(X,Ux_MPCA); Y = proj_3DCCA(Y,Uy_MPCA);
% 
% X = X/max(X(:));  Y = Y/max(Y(:));
% tic
% [Ux,Uy] = STAR(X, Y, max_iter, dim_x, dim_y, epsilon, tolerance);
% toc
% 
% for num_test_per_class = 5
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 0:111:999
% %         data preprocessing
%         idx_test_select = select_test(label, num_test_per_class, rng_factor);
%         idx_train_select = setdiff(idx_all, idx_test_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
%         X_test = X(:,:,:,idx_test_select); X_train = X(:,:,:,idx_train_select);
%         Y_test = Y(:,:,:,idx_test_select); Y_train = Y(:,:,:,idx_train_select);
%                 
%         X_train_proj = proj_3DCCA(X_train,Ux);Y_train_proj = proj_3DCCA(Y_train,Uy);
%         X_test_proj = proj_3DCCA(X_test,Ux);Y_test_proj = proj_3DCCA(Y_test,Uy);
%         
%         vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%         vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
%         
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
%         
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
%         
% %         Classify
%         knn = 1;
%         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%         acc_KNN = cal_acc(estimate, label_test);
%         
%         tic
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
%         toc
%         
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%         iter = iter + 1;
%         
%     end
%     disp(['num_test_per_class = ',num2str(num_test_per_class)])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')
% end

%% Test CASME
% 
% load CASME1_LBP_coding
% load CASME1
% 
% idx_1 = find(label_all == 1)'; idx_4 = find(label_all == 4)';
% idx_3 = find(label_all == 3)';
% idx_6 = find(label_all == 6)'; idx_7 = find(label_all == 7)';
% idx_selected = [idx_1; idx_3; idx_4; idx_6; idx_7];
% 
% X = LBP_coding_video(:,:,:,idx_selected); Y = video_tensor(:,:,:,idx_selected);
% label = label_all(idx_selected);N = length(label); idx_all = 1:N;
% 
% max_iter = 10;
% dim_x = 15; dim_y = 15;
% epsilon = 0.15;
% tolerance = 0.01;
% 
% Ux_MPCA = MPCA_by_rank(X,30); Uy_MPCA = MPCA_by_rank(Y,30);
% X = proj_3DCCA(X,Ux_MPCA); Y = proj_3DCCA(Y,Uy_MPCA);
% 
% X = X/max(X(:));  Y = Y/max(Y(:));
% 
% for number_train_per_class = 6
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 000:111:999
% %         data preprocessing
%         idx_train_select = select_test(label, number_train_per_class, rng_factor);
%         idx_test_select = setdiff(idx_all, idx_train_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
%         X_test = X(:,:,:,idx_test_select); X_train = X(:,:,:,idx_train_select);
%         Y_test = Y(:,:,:,idx_test_select); Y_train = Y(:,:,:,idx_train_select);
% 
%         tic
%         [Ux,Uy] = STAR(X_train, Y_train, max_iter, dim_x, dim_y, epsilon, tolerance);
%         time(iter) = toc
%         sparsity(iter) = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Ux{3}) + nnz(Uy{1}) + nnz(Uy{2}) + nnz(Uy{3}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Ux{3}) + numel(Uy{1}) + numel(Uy{2}) + numel(Uy{3}));
% 
% 
%         X_train_proj = proj_3DCCA(X_train,Ux);Y_train_proj = proj_3DCCA(Y_train,Uy);
%         X_test_proj = proj_3DCCA(X_test,Ux);Y_test_proj = proj_3DCCA(Y_test,Uy);
% 
%         vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%         vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
% 
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
% 
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
% 
% %         Classify
%         knn = 1;
%         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%         acc_KNN = cal_acc(estimate, label_test);
% 
%         tic
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
%         toc
% 
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%         iter = iter + 1;
% 
%     end
%     disp(['num_test_per_class = ',num2str(number_train_per_class)])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')
% end

%% Test JAFFE unpaired
% load jaffe_gabor_feature_pair
% load img_cropped
% X = double(img_all); Y = Gabor_Feature_Tensor2;
% label = label_all;N = length(label); idx_all = 1:N;
% 
% max_iter = 10;
% dim_x = 20; dim_y = 20;
% epsilon = 0.15;
% tolerance = 0.01;
% 
% X = X/max(X(:));  Y = Y/max(Y(:));
% 
% tic
% [Ux,Uy] = STAR(X, Y, max_iter, dim_x, dim_y, epsilon, tolerance);
% toc
% 
% for num_test_per_class = 5
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 0:111:999
% %         data preprocessing
%         idx_test_select = select_test(label, num_test_per_class, rng_factor);
%         idx_train_select = setdiff(idx_all, idx_test_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
%         X_test = X(:,:,idx_test_select); X_train = X(:,:,idx_train_select);
%         Y_test = Y(:,:,:,idx_test_select); Y_train = Y(:,:,:,idx_train_select);
%                 
%         X_train_proj = proj_2DCCA(X_train,Ux{1}, Ux{2});Y_train_proj = proj_3DCCA(Y_train,Uy);
%         X_test_proj = proj_2DCCA(X_test,Ux{1}, Ux{2});Y_test_proj = proj_3DCCA(Y_test,Uy);
%         
%         vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%         vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
%         
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
%         
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
%         
% %         Classify
%         knn = 1;
%         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%         acc_KNN = cal_acc(estimate, label_test);
%         
%         tic
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
%         toc
%         
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%         iter = iter + 1;
%         
%     end
%     disp(['num_test_per_class = ',num2str(num_test_per_class)])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')
% end

%% Test medical data
% clear;
% data_name = 'HIV';
% [X,Y,label] = load_medical_data(data_name);
% N = length(label); idx_all = 1:N;
% 
% [X,~] = my_normalize_tensor(X); [Y,~] = my_normalize_tensor(Y);
% 
% max_iter = 20;
% dim_x = 20; dim_y = 20;
% epsilon = 0.15;
% tolerance = 0.01;
% normalize = 0;
% t_selected = 100;
% 
% for ratio_test_per_class = 0.2
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 0:111:999
%         % data preprocessing
%         idx_test_select = select_test_ratio(label, ratio_test_per_class, rng_factor);
%         idx_train_select = setdiff(idx_all, idx_test_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
%         
%         X_test = X(:,:,idx_test_select); X_train = X(:,:,idx_train_select);
%         Y_test = Y(:,:,idx_test_select); Y_train = Y(:,:,idx_train_select);
%         
%         tic
%         [Ux,Uy, ~, ~, lambda_u, lambda_v] = STAR(X_train, Y_train, max_iter, dim_x, dim_y, epsilon, tolerance, normalize,'rand',t_selected);
%         run_time(iter) = toc;
%         
% %         [U] = generate_rand_sparse_matrix(90,dim_x,0.05); Ux{1} = U; 
% %         [U] = generate_rand_sparse_matrix(90,dim_x,0.05); Ux{2} = U; 
% %         
% %         [U] = generate_rand_sparse_matrix(90,dim_y,0.05); Uy{1} = U;
% %         [U] = generate_rand_sparse_matrix(90,dim_y,0.05); Uy{2} = U;
%                        
%         X_train_proj = proj_2DCCA(X_train,Ux{1}, Ux{2});Y_train_proj = proj_2DCCA(Y_train,Uy{1}, Uy{2});
%         X_test_proj = proj_2DCCA(X_test,Ux{1}, Ux{2});Y_test_proj = proj_2DCCA(Y_test,Uy{1}, Uy{2});
%         
%         % Perform 2DCCA (normal)
%         vec_X_train_proj = tenmat(X_train_proj,3); vec_Y_train_proj = tenmat(Y_train_proj,3);
%         vec_X_test_proj = tenmat(X_test_proj,3); vec_Y_test_proj = tenmat(Y_test_proj,3);
%         
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
%         
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
%         
%         sparsity(iter) =  (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Uy{1}) + nnz(Uy{2}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Uy{1}) + numel(Uy{2}));
%         sparsity(iter) = 1 - sparsity(iter);
%         % Classify
%         knn = 1;
%         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%         acc_KNN = cal_acc(estimate, label_test);
%         
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
%         
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%         iter = iter + 1;
%         
%     end
%     disp(['testing: STAR',' dataset: ',data_name,' ', ' dim_x = ',num2str(dim_x), ' dim_y = ',num2str(dim_y)])
%     disp(['ratio_test_per_class = ',num2str(ratio_test_per_class), ' avg_run_time = ',num2str(mean(run_time)), ' std_run_time = ',num2str(std(run_time))])
%     disp(['avg_sparsity = ',num2str(mean(sparsity)), ' std_sparsity = ',num2str(std(sparsity))])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')
% end

%% Other functions

function X_n = normalize_X(X)

x = X(:);
X_n = X - min(x);
X_n = X_n/max(X_n(:));

end

function U = initialize_U(X,R)
N = ndims(X)-1;
size_X = size(X);
U = cell(N,1);

for i = 1:N
    rng('default');Ui = randn(size_X(i), R);
    U{i} = Ui;
%     U{i} = Ui/norm(Ui,2);
end

end

function X_proj = cal_proj_init(X,U,R)
N = ndims(X);
mode = 1:N-1;
U_r = cell(N-1,1);

sum_proj = 0;
for r = 1:R
    
    for j = 1:N-1
        U_r{j} = U{j}(:,r);
    end
    
    proj_i = double(ttm(tensor(X),U_r,mode,'t'));
    sum_proj = sum_proj + proj_i;
end

X_proj = squeeze(sum_proj);

end

function U_sum = cal_U_sum(U)
R = length(U);
U_sum = 0;

for r = 1:R
    Ur = U{r};
    if(~isempty(Ur))
        U_sum = U_sum + Ur;
    end 
end

end

function X_proj = cal_proj(X, U)
N = size(X,ndims(X));
X_proj = zeros(N,1);

for i = 1:N
    if(ndims(X) == 3)   
        Xi = X(:,:,i);
    else
        Xi = X(:,:,:,i);
    end
    
    Xi_U = Xi(:)'*U(:);
    X_proj_i = sum(Xi_U(:));
    X_proj(i) = X_proj_i;
end

end

function idx_test_select = select_test_ratio(label, ratio_test_per_class, rng_factor)
class_all = unique(label);
num_classes = length(class_all);
idx_test_select = [];
for i = 1:num_classes
    class_i = class_all(i);
    idx_class_i = find(label == class_i);
    num_class_i = length(idx_class_i);
    num_test_class_i = ceil(ratio_test_per_class * num_class_i);
    rng(rng_factor); idx_class_i_perm = randperm(num_class_i);
    idx_test_select_i = idx_class_i(idx_class_i_perm(1:num_test_class_i));
    idx_test_select = [idx_test_select,idx_test_select_i'];
end

end

function idx_test_select = select_test(label, num_test_per_class, rng_factor)
class_all = unique(label);
num_classes = length(class_all);
idx_test_select = zeros(num_classes, num_test_per_class);

for i = 1:num_classes
    class_i = class_all(i);
    idx_class_i = find(label == class_i);
    num_class_i = length(idx_class_i);
    if(num_test_per_class > num_class_i)
        disp('error number test per class');
        return
    end
    rng(rng_factor); idx_class_i_perm = randperm(num_class_i);
    idx_test_select_i = idx_class_i(idx_class_i_perm(1:num_test_per_class));
    idx_test_select(i,:) = idx_test_select_i;
end

idx_test_select = idx_test_select';idx_test_select = idx_test_select(:);

end

function X_proj = proj_2DCCA(X,L,R)
if(ndims(X) == 2)
    X_proj = L'*X*R;
else
    N = size(X,ndims(X));
    for i = 1:N
        Xi = X(:,:,i);
        X_proj_i = L'*Xi*R;
        X_proj(:,:,i) = X_proj_i;
    end
end

end

function X_proj = proj_3DCCA(X,U)
X_proj = ttm(tensor(X),U,[1,2,3],'t'); X_proj = double(X_proj);
end

function estimate = KNN_classifier(vec_X_train, vec_X_test, label_train, k)
num_train = size(vec_X_train,1);
num_test = size(vec_X_test,1);
num_class = numel(unique(label_train));
distance = zeros(num_train,1);
for i = 1:num_test
    X_test_i = vec_X_test(i,:);
    for j = 1:num_train
        X_train_j = vec_X_train(j,:);
        distance(j) = norm(X_test_i - X_train_j);
    end
    
    if(k == 1)
        [~,min_idx] = min(distance);
        estimate_i = label_train(min_idx);
        estimate(i) = estimate_i;
    else
        [distance_sort, sort_idx] = sort(distance,'ascend');
        sort_idx_k = sort_idx(1:k);
        label_k = label_train(sort_idx_k);
        for c = 1:num_class
            num_c(c) = numel(find(label_k == c));
        end
        [~,label_num_sort] = sort(num_c,'descend');
        estimate(i) = label_num_sort(1);
    end
end

end

function acc = cal_acc(estimate, gt)
N = length(gt);
sum_acc = 0;
for i = 1:N
    if(estimate(i) == gt(i))
        sum_acc = sum_acc + 1;
    end
end
acc = sum_acc / N;

end

function [X, Y, label, idx_all] = load_dataset(dataname, mode)
data_name = strcat(dataname,'_',mode,'.mat');
load(data_name);

if(strcmp(mode,'wavelet'))
    X = X_origin;
    Y = X_wavelet;
end

if(strcmp(mode,'LBP'))
    X = X_origin;
    Y = X_LBP_regular;
end

if(strcmp(mode,'Downsample'))
    X = X_origin;
    Y = X_downsample;
end

X = double(X); Y = double(Y);
N = length(label); idx_all = 1:N;
end


function [X, Y, label] = load_medical_data(data_name)
load(data_name);

if(strcmp(data_name,'HIV') == 1)
    data = X;
elseif(strcmp(data_name,'BP') == 1)
    data = X_normalize;
end

clear X;

num_data = length(data);

for i = 1:num_data
    data_i = data{i};
    X(:,:,i) = data_i(:,:,1);
    Y(:,:,i) = data_i(:,:,2);
end

% X = dti; Y = fmri;

end

function [U] = generate_rand_sparse_matrix(M,N,density)

R = sprand(M,N,density);
R = full(R);
idx_nnz = find(R~=0);
R(idx_nnz) = 1;
U = R;


end
