clc;

addpath('tensorlab/');
addpath('/Code/tensor_toolbox-v3.2.1/')
addpath '/Code/CCA/Related_lib/Multiclass_SVM'
method_name = 'STAR';
proj_mode = 'vector'; % vector/matrix

%% Test MNIST 012

% Initialization
max_iter = 10;
dim = 30;
epsilon = 0.15;
tolerance = 0.01;

dataset_name = 'MNIST';
load Mnist_012_processed_new
X = upper_all; Y = lower_all; N = length(label); idx_all = 1:N;

% X = X/max(X(:)); Y = Y/max(Y(:));
% 
% tic
% [Ux,Uy] = STAR(X, Y, max_iter, dim, dim, epsilon, tolerance);
% toc
% 
% X_proj = proj_2DCCA(X, Ux{1}, Ux{2}); Y_proj = proj_2DCCA(Y, Uy{1}, Uy{2});
% 
% for ratio_test_per_class = 0.2
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 0:111:999
%         % data preprocessing
%         idx_test_select = select_test_ratio(label, ratio_test_per_class, rng_factor);
%         idx_train_select = setdiff(idx_all, idx_test_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
% 
%         X_test_proj = X_proj(:,:,idx_test_select); X_train_proj = X_proj(:,:,idx_train_select);
%         Y_test_proj = Y_proj(:,:,idx_test_select); Y_train_proj = Y_proj(:,:,idx_train_select);
%         
%         % Perform 2DCCA (normal)
%         vec_X_train_proj = tenmat(X_train_proj,3); vec_Y_train_proj = tenmat(Y_train_proj,3);
%         vec_X_test_proj = tenmat(X_test_proj,3); vec_Y_test_proj = tenmat(Y_test_proj,3);
%         
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
%         
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
% 
%         % Classify
%         knn = 1;
%         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%         acc_KNN = cal_acc(estimate, label_test);
%         
%         tic
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
%         toc
%         %             acc_SVM = 0;
% 
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%         iter = iter + 1;
% 
%     end
%     disp(['testing: STAR',' dataset: ',dataset_name,' ', ' dim = ',num2str(dim)])
%     disp(['ratio_test_per_class = ',num2str(ratio_test_per_class)])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')
% end
% 

% max_iter = 10;
% dim = 10;
% epsilon = 0.1;
% tolerance = 0.01;
% 
% dataset_name = 'MNIST';
% load Mnist_012_processed_new
% X = upper_all; Y = lower_all; N = length(label); idx_all = 1:N;
% 
% % X = X/max(X(:)); Y = Y/max(Y(:)); 
% X = my_normalize_tensor(X); Y = my_normalize_tensor(Y);
% 
% % svm = get_model("OVA", 3);  % K = number of classes
% % svm.hyperparams.C = 5;
% % svm.kernel = "rbf";
% % svm.hyperparams.gamma = 0.1;
% % label = label + 1;
% 
for ratio_test_per_class = 0.2
    iter = 1; acc_all_KNN = zeros(3,1); acc_all_SVM = zeros(3,1);
    for rng_factor = 000:111:999
        % data preprocessing
        idx_test_select = select_test_ratio(label, ratio_test_per_class, rng_factor);
        idx_train_select = setdiff(idx_all, idx_test_select);
        label_test = label(idx_test_select);
        label_train = label(idx_train_select);
        
        X_train = X(:,:,idx_train_select); Y_train = Y(:,:,idx_train_select);
        X_test = X(:,:,idx_test_select); Y_test = Y(:,:,idx_test_select);
        
        tic
        [Ux,Uy, U_t, V_t] = STAR(X_train, Y_train, max_iter, dim, dim, epsilon, tolerance);
        toc
        
        if(strcmp(proj_mode,'matrix') == 1)
            
            sparsity(iter) = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Uy{1}) + nnz(Uy{2}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Uy{1}) + numel(Uy{2}));
            
            X_test_proj = proj_2DCCA(X_test,Ux{1},Ux{2}); X_train_proj = proj_2DCCA(X_train,Ux{1},Ux{2});
            Y_test_proj = proj_2DCCA(Y_test,Uy{1},Uy{2}); Y_train_proj = proj_2DCCA(Y_train,Uy{1},Uy{2});
            
            vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
            vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
            
            vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
            vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
            
        elseif(strcmp(proj_mode,'vector') == 1)
            X_test_proj = cal_proj_all(X_test,U_t);X_train_proj = cal_proj_all(X_train,U_t);
            Y_test_proj = cal_proj_all(Y_test,V_t);Y_train_proj = cal_proj_all(Y_train,V_t);
            
            vec_X_train_proj = X_train_proj; vec_Y_train_proj = Y_train_proj;
            vec_X_test_proj = X_test_proj;   vec_Y_test_proj = Y_test_proj;
        end
       
        
        Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
        Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];

        % Classify
        knn = 1;
        estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
        acc_KNN = cal_acc(estimate, label_test);
        
        tic
        
        svmModel = fitcecoc(Final_train_feature,label_train);
        [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         svm = train_model(svm, Final_train_feature, label_train);
%         estimate = svm.trained.predict(Final_test_feature);
        acc_SVM = cal_acc(estimate, label_test);
        toc

        disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
        acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
        iter = iter + 1;

    end
    disp(['testing: STAR',' dataset: ',dataset_name,' ', ' dim = ',num2str(dim)])
    disp(['ratio_test_per_class = ',num2str(ratio_test_per_class)])
    disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
    disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
    disp('********************************************************************************')
end

%% Test Full MNIST with noise

% % Initialization
% max_iter = 10;
% dim = 20;
% epsilon = 0.15;
% tolerance = 0.01;
% 
% load mnist_origin_noisy.mat
% 
% X_train = train_images(:,:,:); Y_train = noisy_train(:,:,:);
% X_test = test_images; Y_test = noisy_test;
% 
% Mx = mean(X_train,ndims(X_train)); My = mean(Y_train,ndims(Y_train));
% 
% label_train = train_labels + 1; label_test = test_labels + 1;
% label_train = label_train(:);
% 
% X = cat(3,X_train, X_test); Y = cat(3,Y_train, Y_test);
% max_X = max(X(:)); max_Y = max(Y(:));
% 
% svm = get_model("OVA", 10);
% svm.hyperparams.C = 5;
% svm.kernel = "rbf";
% svm.hyperparams.gamma = 0.1;
% 
% X_train = X_train/max_X; Y_train = Y_train/max_Y;
% X_test = X_test/max_X; Y_test = Y_test/max_Y;
% 
% tic
% [Ux,Uy] = STAR(X_train, Y_train, max_iter, dim, dim, epsilon, tolerance);
% toc
% 
% X_train_proj = proj_2DCCA(X_train, Ux{1}, Ux{2}); Y_train_proj = proj_2DCCA(Y_train, Uy{1}, Uy{2});
% X_test_proj = proj_2DCCA(X_test, Ux{1}, Ux{2}); Y_test_proj = proj_2DCCA(Y_test, Uy{1}, Uy{2});
% 
% vec_X_train_proj = tenmat(X_train_proj,3); vec_Y_train_proj = tenmat(Y_train_proj,3);
% vec_X_test_proj = tenmat(X_test_proj,3); vec_Y_test_proj = tenmat(Y_test_proj,3);
% 
% vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
% vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
% 
% Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
% Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
% 
% Mdl = fitcknn(Final_train_feature,label_train,'NumNeighbors',1);
% [estimate] = predict(Mdl, Final_test_feature);
% error = estimate - label_test;
% a = find(error == 0);
% acc = numel(a)/numel(label_test)
% 
% tic
% % svm = get_model("OVA", 10);
% svm = train_model(svm, Final_train_feature,label_train,'verbose', 0);
% toc
% 
% [estimate,SCORE] =  svm.trained.predict(Final_test_feature);
% 
% acc_SVM = cal_acc(estimate, label_test)
% 
% sparsity = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Uy{1}) + nnz(Uy{2}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Uy{1}) + numel(Uy{2}))

%% Test face recog

% max_iter = 10;
% dim_x = 30; dim_y = 30;
% epsilon = 0.15;
% tolerance = 0.01;
% 
% data_name_all = {'YaleB_32x32', 'Yale_32x32', 'Yale_64x64', 'ORL_32x32', 'ORL_64x64'};
% mode_all = {'wavelet','LBP','Downsample'};
% 
% for m = 2
%     mode = mode_all{m};
%     for d = 2
%         dataset_name = data_name_all{d};
%         [X, Y, label, idx_all] = load_dataset(dataset_name, mode);
%         X = my_normalize_tensor(X); Y = my_normalize_tensor(Y);
%         
%         for ratio_test_per_class = 0.2
%             iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%             for rng_factor = 000:111:999
% %                 data preprocessing
%                 idx_test_select = select_test_ratio(label, ratio_test_per_class, rng_factor);
%                 idx_train_select = setdiff(idx_all, idx_test_select);
%                 label_test = label(idx_test_select);
%                 label_train = label(idx_train_select);
%                 
%                 X_train = X(:,:,idx_train_select); Y_train = Y(:,:,idx_train_select);
%                 X_test = X(:,:,idx_test_select); Y_test = Y(:,:,idx_test_select);
%                 
%                 tic
%                 [Ux,Uy, U_t, V_t] = STAR(X_train, Y_train, max_iter, dim_x, dim_y, epsilon, tolerance);
%                 toc
%                 
%                 if(strcmp(proj_mode,'matrix') == 1)
%                 
%                     sparsity(iter) = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Uy{1}) + nnz(Uy{2}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Uy{1}) + numel(Uy{2}));
%                     
%                     X_test_proj = proj_2DCCA(X_test,Ux{1},Ux{2}); X_train_proj = proj_2DCCA(X_train,Ux{1},Ux{2});
%                     Y_test_proj = proj_2DCCA(Y_test,Uy{1},Uy{2}); Y_train_proj = proj_2DCCA(Y_train,Uy{1},Uy{2});
%                     
%                     vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%                     vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
%                     
%                     vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%                     vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
%                     
%                 elseif(strcmp(proj_mode,'vector') == 1)
%                     X_test_proj = cal_proj_all(X_test,U_t);X_train_proj = cal_proj_all(X_train,U_t);
%                     Y_test_proj = cal_proj_all(Y_test,V_t);Y_train_proj = cal_proj_all(Y_train,V_t);
%                     
%                     vec_X_train_proj = X_train_proj; vec_Y_train_proj = Y_train_proj;
%                     vec_X_test_proj = X_test_proj;   vec_Y_test_proj = Y_test_proj;
%                 end
% 
% 
%                 Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%                 Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
% 
% %                 Classify
%                 knn = 1;
%                 estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%                 acc_KNN = cal_acc(estimate, label_test);
%                 
%                 tic
% 
%                 svmModel = fitcecoc(Final_train_feature,label_train);
%                 [estimate,SCORE] = predict(svmModel, Final_test_feature);
%                 acc_SVM = cal_acc(estimate, label_test);
%                 toc
% %                 acc_SVM = 0;
% 
%                 disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%                 acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%                 iter = iter + 1;
% 
%             end
%             disp(['ratio_test_per_class = ',num2str(ratio_test_per_class)])
%             disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%             disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%             disp('********************************************************************************')
%         end
%     end
% 
% end

%% Test Gait

% Initialization

% max_iter = 5;
% dim_x = 20; dim_y = 20;
% epsilon = 0.15;
% tolerance = 0.01;
% 
% dataset = 'Gait17_32x22x10_processed';
% load(dataset)
% X = double(U); Y = double(V);
% X = X/max(X(:));  Y = Y/max(Y(:));
% N = length(label); idx_all = 1:N;
% 
% tic
% [Ux,Uy] = STAR(X, Y, max_iter, dim_x, dim_y, epsilon, tolerance);
% toc
% 
% for num_test_per_class = 2
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 0:111:999
%         % data preprocessingc
%         idx_test_select = select_test(label, num_test_per_class, rng_factor);
%         idx_train_select = setdiff(idx_all, idx_test_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
%         X_test = X(:,:,:,idx_test_select); X_train = X(:,:,:,idx_train_select);
%         Y_test = Y(:,:,:,idx_test_select); Y_train = Y(:,:,:,idx_train_select);
% 
%         X_train_proj = proj_3DCCA(X_train,Ux);Y_train_proj = proj_3DCCA(Y_train,Uy);
%         X_test_proj = proj_3DCCA(X_test,Ux);Y_test_proj = proj_3DCCA(Y_test,Uy);
% 
%         vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%         vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
% 
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
% 
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
% 
%         % Classify
% %         knn = 1;
% %         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
% %         acc_KNN = cal_acc(estimate, label_test);
%         acc_KNN = 0;
% 
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
% %         acc_SVM = 0;
% 
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%         iter = iter + 1;
% 
%     end
%     disp(['num_test_per_class = ',num2str(num_test_per_class)])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')
% end

%% Test JAFFE

% max_iter = 50;
% dim_x = 20; dim_y = 20;
% epsilon = 0.15;
% tolerance = 0.01;
% 
% load jaffe_gabor_feature_pair
% X = Gabor_Feature_Tensor1; Y = Gabor_Feature_Tensor2;
% label = label_all;N = length(label); idx_all = 1:N;
% Ux_MPCA = MPCA(X,0.98); Uy_MPCA = MPCA(Y,0.98);
% X = proj_3DCCA(X,Ux_MPCA); Y = proj_3DCCA(Y,Uy_MPCA);
% 
% X = X/max(X(:));  Y = Y/max(Y(:));
% tic
% [Ux,Uy] = STAR(X, Y, max_iter, dim_x, dim_y, epsilon, tolerance);
% toc
% 
% for num_test_per_class = 5
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 0:111:999
% %         data preprocessing
%         idx_test_select = select_test(label, num_test_per_class, rng_factor);
%         idx_train_select = setdiff(idx_all, idx_test_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
%         X_test = X(:,:,:,idx_test_select); X_train = X(:,:,:,idx_train_select);
%         Y_test = Y(:,:,:,idx_test_select); Y_train = Y(:,:,:,idx_train_select);
%                 
%         X_train_proj = proj_3DCCA(X_train,Ux);Y_train_proj = proj_3DCCA(Y_train,Uy);
%         X_test_proj = proj_3DCCA(X_test,Ux);Y_test_proj = proj_3DCCA(Y_test,Uy);
%         
%         vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%         vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
%         
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
%         
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
%         
% %         Classify
%         knn = 1;
%         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%         acc_KNN = cal_acc(estimate, label_test);
%         
%         tic
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
%         toc
%         
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%         iter = iter + 1;
%         
%     end
%     disp(['num_test_per_class = ',num2str(num_test_per_class)])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')
% end


%% Test Medical data

% max_iter = 10;
% dim_x = 30; dim_y = 30;
% epsilon = 0.15;
% tolerance = 0.01;
% 
% warning('off')
% dataset_name = 'HIV.mat';
% 
% load(dataset_name)
% N = length(label); idx_all = 1:N;
% 
% if(strcmp(dataset_name, 'BP.mat'))
%     data = X_normalize;
% else
%     data = X;
% end
% 
% X = dti; Y = fmri; ratio = 0.2;
% 
% X = double(X)/max(X(:));  Y = double(Y)/max(Y(:));
% 
% [Ux,Uy] = STAR(X, Y, max_iter, dim_x, dim_y, epsilon, tolerance);
% 
% X_proj = proj_2DCCA(X, Ux{1}, Ux{2}); Y_proj = proj_2DCCA(Y, Uy{1}, Uy{2});
% 
% for ratio_test_per_class = 0.2
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 0:111:999
%         % data preprocessing
%         idx_test_select = select_test_ratio(label, ratio_test_per_class, rng_factor);
%         idx_train_select = setdiff(idx_all, idx_test_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
%        
%         X_test_proj = X_proj(:,:,idx_test_select); X_train_proj = X_proj(:,:,idx_train_select);
%         Y_test_proj = Y_proj(:,:,idx_test_select); Y_train_proj = Y_proj(:,:,idx_train_select);
%         
%         % Perform 2DCCA (normal)
%         vec_X_train_proj = tenmat(X_train_proj,3); vec_Y_train_proj = tenmat(Y_train_proj,3);
%         vec_X_test_proj = tenmat(X_test_proj,3); vec_Y_test_proj = tenmat(Y_test_proj,3);
%         
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
%         
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
%         
%         % Classify
%         knn = 1;
%         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%         acc_KNN = cal_acc(estimate, label_test);
%         
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
%         %                 acc_SVM = 0;
%         
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%         iter = iter + 1;
%         
%     end
%     disp(['testing: SPTCCA_Wang',' dataset: ',dataset_name,' ', ' dim_x = ',num2str(dim_x), ' dim_y = ',num2str(dim_y)])
%     disp(['ratio_test_per_class = ',num2str(ratio_test_per_class)])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')
% end

%% Test CASME

% load CASME1_LBP_coding
% load CASME1
% 
% idx_1 = find(label_all == 1)'; idx_4 = find(label_all == 4)';
% idx_3 = find(label_all == 3)';
% idx_6 = find(label_all == 6)'; idx_7 = find(label_all == 7)';
% idx_selected = [idx_1; idx_3; idx_4; idx_6; idx_7];
% 
% X = LBP_coding_video(:,:,:,idx_selected); Y = video_tensor(:,:,:,idx_selected);
% label = label_all(idx_selected);N = length(label); idx_all = 1:N;
% 
% max_iter = 10;
% dim_x = 15; dim_y = 15;
% epsilon = 0.15;
% tolerance = 0.01;
% 
% 
% Ux_MPCA = MPCA_my(X,30); Uy_MPCA = MPCA_my(Y,30);
% X = proj_3DCCA(X,Ux_MPCA); Y = proj_3DCCA(Y,Uy_MPCA);
% 
% X = X/max(X(:));  Y = Y/max(Y(:));
% X = normalize(X); Y = normalize(Y);
% tic
% [Ux,Uy] = STAR(X, Y, max_iter, dim_x, dim_y, epsilon, tolerance);
% toc
% 
% for num_test_per_class = 2
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 0:111:999
% %         data preprocessing
%         idx_test_select = select_test(label, num_test_per_class, rng_factor);
%         idx_train_select = setdiff(idx_all, idx_test_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
%         X_test = X(:,:,:,idx_test_select); X_train = X(:,:,:,idx_train_select);
%         Y_test = Y(:,:,:,idx_test_select); Y_train = Y(:,:,:,idx_train_select);
% 
% %         tic
% %         [Ux,Uy] = STAR(X_train, Y_train, max_iter, dim_x, dim_y, epsilon, tolerance);
% %         toc
% 
%         X_train_proj = proj_3DCCA(X_train,Ux);Y_train_proj = proj_3DCCA(Y_train,Uy);
%         X_test_proj = proj_3DCCA(X_test,Ux);Y_test_proj = proj_3DCCA(Y_test,Uy);
% 
%         vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%         vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
% 
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
% 
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
% 
% %         Classify
%         knn = 1;
%         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%         acc_KNN = cal_acc(estimate, label_test);
% 
%         tic
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
%         toc
% 
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%         iter = iter + 1;
% 
%     end
%     disp(['num_test_per_class = ',num2str(num_test_per_class)])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')
% end


% load CASME1_LBP_coding
% load CASME1
% 
% idx_1 = find(label_all == 1)'; idx_4 = find(label_all == 4)';
% idx_3 = find(label_all == 3)';
% idx_6 = find(label_all == 6)'; idx_7 = find(label_all == 7)';
% idx_selected = [idx_1; idx_3; idx_4; idx_6; idx_7];
% 
% X = LBP_coding_video(:,:,:,idx_selected); Y = video_tensor(:,:,:,idx_selected);
% label = label_all(idx_selected);N = length(label); idx_all = 1:N;
% 
% max_iter = 10;
% dim_x = 15; dim_y = 15;
% epsilon = 0.15;
% tolerance = 0.01;
% 
% Ux_MPCA = MPCA_my(X,30); Uy_MPCA = MPCA_my(Y,30);
% X = proj_3DCCA(X,Ux_MPCA); Y = proj_3DCCA(Y,Uy_MPCA);
% 
% X = X/max(X(:));  Y = Y/max(Y(:));
% 
% for number_train_per_class = 6
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 000:111:999
% %         data preprocessing
%         idx_train_select = select_test(label, number_train_per_class, rng_factor);
%         idx_test_select = setdiff(idx_all, idx_train_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
%         X_test = X(:,:,:,idx_test_select); X_train = X(:,:,:,idx_train_select);
%         Y_test = Y(:,:,:,idx_test_select); Y_train = Y(:,:,:,idx_train_select);
% 
%         tic
%         [Ux,Uy] = STAR(X_train, Y_train, max_iter, dim_x, dim_y, epsilon, tolerance);
%         time(iter) = toc
%         sparsity(iter) = (nnz(Ux{1}) + nnz(Ux{2}) + nnz(Ux{3}) + nnz(Uy{1}) + nnz(Uy{2}) + nnz(Uy{3}))/(numel(Ux{1}) + numel(Ux{2}) + numel(Ux{3}) + numel(Uy{1}) + numel(Uy{2}) + numel(Uy{3}));
% 
% 
%         X_train_proj = proj_3DCCA(X_train,Ux);Y_train_proj = proj_3DCCA(Y_train,Uy);
%         X_test_proj = proj_3DCCA(X_test,Ux);Y_test_proj = proj_3DCCA(Y_test,Uy);
% 
%         vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%         vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
% 
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
% 
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
% 
% %         Classify
%         knn = 1;
%         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%         acc_KNN = cal_acc(estimate, label_test);
% 
%         tic
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
%         toc
% 
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%         iter = iter + 1;
% 
%     end
%     disp(['num_test_per_class = ',num2str(number_train_per_class)])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')
% end

%% Test JAFFE unpaired
% load jaffe_gabor_feature_pair
% load img_cropped
% X = double(img_all); Y = Gabor_Feature_Tensor2;
% label = label_all;N = length(label); idx_all = 1:N;
% 
% max_iter = 10;
% dim_x = 20; dim_y = 20;
% epsilon = 0.15;
% tolerance = 0.01;
% 
% X = X/max(X(:));  Y = Y/max(Y(:));
% 
% tic
% [Ux,Uy] = STAR(X, Y, max_iter, dim_x, dim_y, epsilon, tolerance);
% toc
% 
% for num_test_per_class = 5
%     iter = 1; acc_all_KNN = zeros(10,1); acc_all_SVM = zeros(10,1);
%     for rng_factor = 0:111:999
% %         data preprocessing
%         idx_test_select = select_test(label, num_test_per_class, rng_factor);
%         idx_train_select = setdiff(idx_all, idx_test_select);
%         label_test = label(idx_test_select);
%         label_train = label(idx_train_select);
%         X_test = X(:,:,idx_test_select); X_train = X(:,:,idx_train_select);
%         Y_test = Y(:,:,:,idx_test_select); Y_train = Y(:,:,:,idx_train_select);
%                 
%         X_train_proj = proj_2DCCA(X_train,Ux{1}, Ux{2});Y_train_proj = proj_3DCCA(Y_train,Uy);
%         X_test_proj = proj_2DCCA(X_test,Ux{1}, Ux{2});Y_test_proj = proj_3DCCA(Y_test,Uy);
%         
%         vec_X_train_proj = tenmat(X_train_proj,ndims(X)); vec_Y_train_proj = tenmat(Y_train_proj,ndims(Y));
%         vec_X_test_proj = tenmat(X_test_proj,ndims(X)); vec_Y_test_proj = tenmat(Y_test_proj,ndims(Y));
%         
%         vec_X_train_proj = double(vec_X_train_proj); vec_Y_train_proj = double(vec_Y_train_proj);
%         vec_X_test_proj = double(vec_X_test_proj); vec_Y_test_proj = double(vec_Y_test_proj);
%         
%         Final_train_feature = [vec_X_train_proj,vec_Y_train_proj];
%         Final_test_feature = [vec_X_test_proj,vec_Y_test_proj];
%         
% %         Classify
%         knn = 1;
%         estimate = KNN_classifier(Final_train_feature, Final_test_feature, label_train, knn);
%         acc_KNN = cal_acc(estimate, label_test);
%         
%         tic
%         svmModel = fitcecoc(Final_train_feature,label_train);
%         [estimate,SCORE] = predict(svmModel, Final_test_feature);
%         acc_SVM = cal_acc(estimate, label_test);
%         toc
%         
%         disp(['iter  = ',num2str(iter),' acc_KNN = ',num2str(acc_KNN), ' acc_SVM = ', num2str(acc_SVM)]);
%         acc_all_KNN(iter) = acc_KNN; acc_all_SVM(iter) = acc_SVM;
%         iter = iter + 1;
%         
%     end
%     disp(['num_test_per_class = ',num2str(num_test_per_class)])
%     disp([' acc_KNN = ',num2str(mean(acc_all_KNN)), ' acc_SVM = ', num2str(mean(acc_all_SVM))])
%     disp([' std_KNN = ',num2str(std(acc_all_KNN)), ' std_SVM = ', num2str(std(acc_all_SVM))])
%     disp('********************************************************************************')
% end

%% Other functions

function [U_cell,V_cell, U_t, V_t] = STAR(X, Y, max_iter, Rx, Ry, epsilon, tolerance)

N_samples = size(X,ndims(X));

Xc = X - mean(X,ndims(X));
Yc = Y - mean(Y,ndims(Y));

% Use randn for initialization
[init_U] = initialize_U(Xc,Rx);
[init_V] = initialize_U(Yc,Ry);

% Use MPCA for initialization (Faster)
% [init_U] = MPCA_my(Xc, Rx);
% [init_V] = MPCA_my(Yc, Rx);


X_proj = cal_proj_init(Xc,init_U,Rx);
Y_proj = cal_proj_init(Yc,init_V,Ry);

vec_X = double(tenmat(Xc, ndims(Xc)));
vec_Y = double(tenmat(Yc, ndims(Yc)));


for i = 1:max_iter
    
    error_old = norm(X_proj - Y_proj)/N_samples;
    % update U
    [~,U_t,U_cell, sigma_u,res_UX] = STAR_simple(Xc, vec_X, Y_proj, Rx, epsilon);
    U_new = cal_U_sum(U_t);
    X_proj = cal_proj(Xc, U_new);
    
    % update V
    [~,V_t,V_cell, sigma_v,res_VY] = STAR_simple(Yc, vec_Y, X_proj, Ry, epsilon);
    V_new = cal_U_sum(V_t);
    Y_proj = cal_proj(Yc, V_new);
%     
%     if(i == 1)
%         U_old = U_new;
%         V_old = V_new;
%     end
%     
%     error_new = norm(X_proj - Y_proj)^2/N_samples;
%     if(abs(error_new - error_old)<0.001)
%         disp('model converge')
%         break;
%     end
%     
%     if(i > 1)
%         error_U = norm(U_new(:) - U_old(:),'fro');
%         error_V = norm(V_new(:) - V_old(:),'fro');
%         error_new = norm(X_proj - Y_proj);
%         abs(error_new - error_old)^2
%         if(error_U < tolerance && error_V < tolerance)
%             disp('model converge')
%             break;
%         else
%             U_old = U_new; V_old = V_new;
%         end          
%     end
    
end


end

function X_n = normalize_X(X)

x = X(:);
X_n = X - min(x);
X_n = X_n/max(X_n(:));

end

function U = initialize_U(X,R)
N = ndims(X)-1;
size_X = size(X);
U = cell(N,1);

for i = 1:N
    rng('default');Ui = randn(size_X(i), R);
    U{i} = Ui;
%     U{i} = Ui/norm(Ui,2);
end

end

function X_proj = cal_proj_init(X,U,R)
N = ndims(X);
mode = 1:N-1;
U_r = cell(N-1,1);

sum_proj = 0;
for r = 1:R
    
    for j = 1:N-1
        U_r{j} = U{j}(:,r);
    end
    
    proj_i = double(ttm(tensor(X),U_r,mode,'t'));
    sum_proj = sum_proj + proj_i;
end

X_proj = squeeze(sum_proj);

end

function U_sum = cal_U_sum(U)
R = length(U);
U_sum = 0;

for r = 1:R
    Ur = U{r};
    if(~isempty(Ur))
        U_sum = U_sum + Ur;
    end 
end

end

function X_proj = cal_proj(X, U)
N = size(X,ndims(X));
X_proj = zeros(N,1);

for i = 1:N
    if(ndims(X) == 3)   
        Xi = X(:,:,i);
    else
        Xi = X(:,:,:,i);
    end
    
    Xi_U = Xi(:)'*U(:);
    X_proj_i = sum(Xi_U(:));
    X_proj(i) = X_proj_i;
end

end

function X_proj = cal_proj_all(X,U)
N = size(X,ndims(X));
R = length(U);
ndim_X = ndims(X);

for i = 1:N
    if(ndim_X == 3)
        Xi = X(:,:,i);
    else
        Xi = X(:,:,:,i);
    end
    Xi = Xi(:);
    for r = 1:R
        U_r = U{r};
        if(~isempty(U_r))
            U_r = U_r(:);
            X_proj(i,r) = Xi'*U_r;
        end
    end
end

end

function idx_test_select = select_test_ratio(label, ratio_test_per_class, rng_factor)
class_all = unique(label);
num_classes = length(class_all);
idx_test_select = [];
for i = 1:num_classes
    class_i = class_all(i);
    idx_class_i = find(label == class_i);
    num_class_i = length(idx_class_i);
    num_test_class_i = ceil(ratio_test_per_class * num_class_i);
    rng(rng_factor); idx_class_i_perm = randperm(num_class_i);
    idx_test_select_i = idx_class_i(idx_class_i_perm(1:num_test_class_i));
    idx_test_select = [idx_test_select,idx_test_select_i'];
end

end

function idx_test_select = select_test(label, num_test_per_class, rng_factor)
class_all = unique(label);
num_classes = length(class_all);
idx_test_select = zeros(num_classes, num_test_per_class);

for i = 1:num_classes
    class_i = class_all(i);
    idx_class_i = find(label == class_i);
    num_class_i = length(idx_class_i);
    if(num_test_per_class > num_class_i)
        disp('error number test per class');
        return
    end
    rng(rng_factor); idx_class_i_perm = randperm(num_class_i);
    idx_test_select_i = idx_class_i(idx_class_i_perm(1:num_test_per_class));
    idx_test_select(i,:) = idx_test_select_i;
end

idx_test_select = idx_test_select';idx_test_select = idx_test_select(:);

end

function X_proj = proj_2DCCA(X,L,R)
if(ndims(X) == 2)
    X_proj = L'*X*R;
else
    N = size(X,ndims(X));
    for i = 1:N
        Xi = X(:,:,i);
        X_proj_i = L'*Xi*R;
        X_proj(:,:,i) = X_proj_i;
    end
end

end

function X_proj = proj_3DCCA(X,U)
X_proj = ttm(tensor(X),U,[1,2,3],'t'); X_proj = double(X_proj);
end

function estimate = KNN_classifier(vec_X_train, vec_X_test, label_train, k)
num_train = size(vec_X_train,1);
num_test = size(vec_X_test,1);
num_class = numel(unique(label_train));
distance = zeros(num_train,1);
for i = 1:num_test
    X_test_i = vec_X_test(i,:);
    for j = 1:num_train
        X_train_j = vec_X_train(j,:);
        distance(j) = norm(X_test_i - X_train_j);
    end
    
    if(k == 1)
        [~,min_idx] = min(distance);
        estimate_i = label_train(min_idx);
        estimate(i) = estimate_i;
    else
        [distance_sort, sort_idx] = sort(distance,'ascend');
        sort_idx_k = sort_idx(1:k);
        label_k = label_train(sort_idx_k);
        for c = 1:num_class
            num_c(c) = numel(find(label_k == c));
        end
        [~,label_num_sort] = sort(num_c,'descend');
        estimate(i) = label_num_sort(1);
    end
end

end

function acc = cal_acc(estimate, gt)
N = length(gt);
sum_acc = 0;
for i = 1:N
    if(estimate(i) == gt(i))
        sum_acc = sum_acc + 1;
    end
end
acc = sum_acc / N;

end

function [X, Y, label, idx_all] = load_dataset(dataname, mode)
data_name = strcat(dataname,'_',mode,'.mat');
load(data_name);

if(strcmp(mode,'wavelet'))
    X = X_origin;
    Y = X_wavelet;
end

if(strcmp(mode,'LBP'))
    X = X_origin;
    Y = X_LBP_regular;
end

if(strcmp(mode,'Downsample'))
    X = X_origin;
    Y = X_downsample;
end

X = double(X); Y = double(Y);
N = length(label); idx_all = 1:N;
end


function [U] = MPCA_my(X, r)
%MPCA 此处显示有关此函数的摘要
%   此处显示详细说明
dim_X = ndims(X);X = tensor(X);
for i = 1:dim_X-1
    Xi = double(tenmat(X,i));
    Ui = cal_U(Xi,r);
    U{i} = Ui;
end

end

function U = cal_U(X,rank)
[U,S,~] = svd(X*X');
U = U(:,1:rank);

end
