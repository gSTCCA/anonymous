X = rand(4,4,3);
w{1} = rand(4,1)'; w{2} = rand(4,1)'; sigma = 0.02;
W = w{1}' * w{2} * sigma;

X_proj = cal_proj(X,W);
a = ttm(tensor(X),w,[1,2],'nt') * sigma;
a = double(a);

function proj = cal_proj(X, W)
N = size(X,ndims(X));
proj = 0;
w = W(:);

for i = 1:N
    if(ndims(X) == 4)
        Xi = X(:,:,:,i);
    else
        Xi = X(:,:,i);
    end
    xi = Xi(:);
    sum_i = xi'*w;
    proj(i) = sum_i;
end

end